#ifndef __USART_INIT_CONFIG_H
#define __USART_INIT_CONFIG_H

#include "stm32f10x.h"
void USART_Init_Config(void);

#endif
