#include "stm32f10x.h"
#include <stdio.h>
#include "led.h"
#include "USART_Init_Config.h"

int main(void)
{  
   while(1)
   {
	 }
}
